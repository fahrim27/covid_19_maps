@extends('admin.app')

@section('content')
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-sm-6 col-xl-6">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="icon-profile bg-primary  text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Jumlah Pasien Positif</h5>
                            </div>
                            <?php 
                                $user = Auth::user()->nrp;

                                $idPosko = explode("-", $user);
                                $kelurahan_id = App\Posko::select('kelurahan_id')->where('id', $idPosko[1])->first()->kelurahan_id;
                            ?>
                            <h3 class="mt-4">{{App\Pasien::where('kelurahan_id', $kelurahan_id)->where('jenis_kasus_id', 1)->count()}} Pasien</h3>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-6">
                    <div class="card">
                        <div class="card-heading p-4">
                            <div class="mini-stat-icon float-right">
                                <i class="mdi mdi-account-group bg-success text-white"></i>
                            </div>
                            <div>
                                <h5 class="font-16">Nama Posko</h5>
                            </div>
                            <h3 class="mt-4">{{Auth::user()->nrp}}, Kelurahan {{App\Kelurahan::select('nama')->where('id', $kelurahan_id)->first()->nama}}</h3>
                        </div>
                    </div>
                </div>

            </div>
            <!-- end row -->                                                    

        </div>
        <!-- container-fluid -->

    </div>
    <!-- content -->


</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->

@endsection