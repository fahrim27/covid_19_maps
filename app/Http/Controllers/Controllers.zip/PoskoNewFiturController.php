<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Posko;
use App\Pasien;
use Auth;

class PoskoNewFiturController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('posko.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexPasienPosko()
    {
        $user = Auth::user()->nrp;

        $idPosko = explode("-", $user);
        $kelurahan_id = Posko::select('kelurahan_id')->where('id', $idPosko[1])->first()->kelurahan_id;

        $pasienPositif = Pasien::where('kelurahan_id', $kelurahan_id)->where('jenis_kasus_id', 1)->get();

        return view('posko.pasien', compact('pasienPositif'));
    }

    public function setIntervalPasien()
    {
        $user = Auth::user()->nrp;

        $idPosko = explode("-", $user);
        $kelurahan_id = Posko::select('kelurahan_id')->where('id', $idPosko[1])->first()->kelurahan_id;

        $pasienPositif = Pasien::where('kelurahan_id', $kelurahan_id)->where('jenis_kasus_id', 1)->get();

        return view('posko.ajaxReload', compact('pasienPositif'));   
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
