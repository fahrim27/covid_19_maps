<table id="datatable table-pasien" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Nama Pasien</th>
                                                    <th>Skor</th>
                                                    <th>Suhu</th>
                                                    <th>1</th>
                                                    <th>2</th>
                                                    <th>3</th>
                                                    <th>4</th>
                                                    <th>5</th>
                                                    <th>7</th>
                                                    <th>8</th>
                                                    <th>9</th>
                                                    <th>10</th>
                                                    <th>11</th>
                                                    <th>12</th>
                                                    <th>13</th>
                                                    <th>14</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            @php $i=1 @endphp
                                            <tbody id="organisasi_body">
                                                @foreach($pasienPositif as $positif)
                                                <tr id="item{{$positif->id}}">
                                                    <td>{!! $positif->nama !!}</td>
                                                    <?php $dateNow = date("Y-m-d"); ?>
                                                    @foreach(App\Penilaian::where('user_id', $positif->user_id)->where('tanggal', $dateNow)->get() as $rundown)
                                                        @if($rundown->status == 0)
                                                        <td><i class="fas fa-sad-tear" style="font-size: 19px;"></i></td>
                                                        @else
                                                        <td><i class="fas fa-smile-beam"></i></td>
                                                        @endif
                                                    @endforeach
                                                    {{-- <td>{{date('j F Y', strtotime ($rs->created_at))}}</td> --}}
                                                    <td>
                                                        <a data-id="{{$positif->id}}" class="btn btn-outline-success detail" data-toggle="modal"><i class="fab fa-whatsapp" style="color: white;"></i></a>
                                                        <a data-id="{{$positif->id}}" class="btn btn-outline-danger detail" data-toggle="modal"><i class="far fa-trash-alt" style="color: white;"></i></a>
                                                      </td>
                                                </tr>

                                                @endforeach
                                            </tbody>
                                        </table>